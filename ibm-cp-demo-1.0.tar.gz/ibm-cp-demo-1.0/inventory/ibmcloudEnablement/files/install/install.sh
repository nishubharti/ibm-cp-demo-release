#!/bin/bash
#******************************************************************************
# Licensed Materials - Property of IBM
# (c) Copyright IBM Corporation 2019. All Rights Reserved.
#
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#******************************************************************************

# LOGIN
printf "%s" "$KUBECONFIG_VALUE" > ./kubeconfig.json
printf "%s" "$KUBECONFIG_PEM_VALUE" > ./ca.pem

# Clean up pem file contents
sed -i 's/\\n/\n/g' ca.pem
sed -i 's/\"//g' ca.pem
echo "Installing Dummy cloudpak...."
sleep 10
oc project
oc status
oc get po
kubectl get svc
oc create namespace dummy-cloudpak-ns
oc project dummy-cloudpak-ns
echo "Done...."
