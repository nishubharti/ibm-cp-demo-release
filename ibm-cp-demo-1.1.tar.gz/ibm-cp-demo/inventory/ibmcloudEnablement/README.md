# Name

IBM&reg; Cloud Pak for Applications

# Introduction
## Summary

Cloud Pak for Applications is an enterprise-ready, containerized software solution for modernizing existing applications and developing new cloud-native apps that run on Red Hat&reg; OpenShift&reg;. This hybrid, multicloud foundation breaks down technology and data silos to make modernization faster and more secure, and speeds development of applications built for Kubernetes, so you can access cloud services — all while meeting the technology standards and policies your company requires.

Learn more here:  https://www.ibm.com/cloud/cloud-pak-for-applications

## Features

- **IBM WebSphere Application Server**

  WebSphere&reg; Application Server, with its traditional and Liberty runtimes, offers industry-leading, production-ready, standards-based Java&trade; EE-compliant architectures. Cloud Pak for Applications include WebSphere Application Server ND, WebSphere Application Server, and the WebSphere Liberty Core editions with the ability to easily mix and match between them. 

- **Red Hat OpenShift Container Platform**

  Red Hat OpenShift delivers a comprehensive solution for hybrid cloud, enterprise container, and Kubernetes development and deployments. It includes an enterprise-grade Linux® operating system, container runtime, networking, monitoring, container registry, authentication, and authorization solutions. 

- **Kabanero Enterprise**

  Kabanero&trade; Enterprise is the commercial, enterprise-ready, and fully supported implementation of the Kabanero.io open source community project. Kabanero Enterprise integrates with, extends, and adds value to Red Hat OpenShift.  The Kabanero open source project is focused on bringing together foundational open source technologies into a modern microservices-based framework. 

- **Red Hat Runtimes**

  Red Hat Runtimes provides a set of open runtimes, tools, and components for developing and maintaining cloud-native applications. It offers lightweight runtimes and frameworks for highly distributed cloud architectures, such as microservices.

- **IBM Mobile Foundation**

  IBM Mobile Foundation offers an industry-leading secured platform for developers to rapidly build and deploy the next generation of digital apps, including mobile, wearables, conversation, web, and PWAs. With Mobile Foundation, developers get containerized mobile back-end services covering comprehensive security, application life cycle management, push notifications, feature toggle, off-line sync, and back-end integration. 

- **IBM Modernization & Developer Tools**

  Included at no cost are modernization tools such as IBM Cloud&trade; Transformation Advisor to assist with your move to the cloud, and developer tools such as Eclipse Codewind to build and deploy your new cloud-native applications with the IDE of your choice.

- **IBM Cloud Private**

  IBM Cloud Private is a private cloud platform that provides the benefits of the public cloud from the safety of your firewall-protected data center. With the acquisition of Red Hat, IBM is standardizing on Red Hat OpenShift Container Platform as its platform for cloud native, container based, Kubernetes orchestration. Entitlement to IBM Cloud Private is included in Cloud Pak for Applications to facilitate the transition to OpenShift.

- **IBM Application Navigator**

  IBM Application Navigator is a tool that helps you visualize, inspect, and conduct day 2 operations on the deployed resources that comprise your applications. Additionally, it provides a single view across hybrid deployments in support of application modernization. During modernization of your applications, App Navigator helps you include JEE applications from WebSphere Application Server in your application view. App Navigator extends the open source Kubernetes Application Navigator (kAppNav) with integrated support for Network Deployment.

Cloud Pak for Applications provides several software offerings in one bundle. Using this installation method, only Kabanero Enterprise, Transformation Advisor, and Application Navigator will be installed. See https://cloud.ibm.com/docs/cloud-pak-applications?topic=cloud-pak-applications-getting-started for more information.

# Details
## Prerequisites
### Resources Required
Minimum scheduling capacity:

| Software | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --- | --- | --- | --- | --- |
| Kabanero Enterprise | 20 | 8 | 25 | 2 |
| Transformation Advisor | 6 | 3 | 8 | |
| Application Navigator | 1 | 1 | 3 | |
| **Total** | **27** | **12**  | **36**  | **2** |


# Installing
For installation instructions, see https://cloud.ibm.com/docs/cloud-pak-applications?topic=cloud-pak-applications-getting-started .

## Configuration
If desired, you can set the consoleRoutePrefix parameter. This value is used as the subdomain in the URL for the Cloud Pak for Applications landing page; the remainder is the OpenShift Cluster Console URL.

## Storage
By default, Transformation Advisor is configured to use dynamic provisioning. If dynamic provisioning is not available or you choose not to use it, Transformation Advisor can bind to a suitable statically created PersistentVolume.

## Limitations
Only one installation of Cloud Pak for Applications per cluster is supported at this time.

## Documentation
Documentation for Cloud Pak for Applications can be found at https://cloud.ibm.com/docs/cloud-pak-applications?topic=cloud-pak-applications-about .
